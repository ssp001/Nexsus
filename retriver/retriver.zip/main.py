from service import RetriverService

retriver_service = RetriverService()


async def lamda_fuction(event, context):
    user_id = event.get("sub")
    respones = await retriver_service.run_retriver(document_id=___, query=___)
    return respones
