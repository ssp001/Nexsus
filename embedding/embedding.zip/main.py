from service import EmbeddingService

embedding_service = EmbeddingService()


def lambda_event(context, event):

    key = event.get("key")
    json_tree, docs_id = embedding_service.cerate_knowladgebase(file=key)
    return {
        "json_tree": json_tree,
        "document_id": docs_id
    }
